// Copyright (c) 2015, Baidu.com, Inc. All Rights Reserved
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "sdk/sdk_zk.h"

#include <iostream>
#include <gflags/gflags.h>

#include "types.h"
#include "zk/zk_adapter.h"

DECLARE_string(tera_zk_lib_log_path);
DECLARE_string(tera_fake_zk_path_prefix);
DECLARE_bool(tera_zk_enabled);

namespace tera {
namespace sdk {

pthread_once_t ClusterFinder::_zk_init_once = PTHREAD_ONCE_INIT;

ClusterFinder::ClusterFinder(std::string zk_root_path, const std::string& zk_addr_list)
    : _zk_root_path(zk_root_path),
      _zk_addr_list(zk_addr_list) {
}

void ClusterFinder::InitZkLogOnce() {
    zk::ZooKeeperLightAdapter::SetLibraryLogOutput(FLAGS_tera_zk_lib_log_path);
}

bool ClusterFinder::ReadZkNode(const std::string path, std::string* value) {
    pthread_once(&_zk_init_once, InitZkLogOnce);

    int zk_errno = tera::zk::ZE_OK;

    zk::ZooKeeperLightAdapter zk_adapter;
    if (!zk_adapter.Init(_zk_addr_list, _zk_root_path,
                         1000*15, "", &zk_errno)) {
        std::cout << "Init zookeeper fail: "
            << tera::zk::ZkErrnoToString(zk_errno) << std::endl;
        return false;
    }

    if (!zk_adapter.ReadNode(path, value, &zk_errno)) {
        std::cout<< "ReadZkNode fail: "<< zk::ZkErrnoToString(zk_errno) << std::endl;
        return false;
    }
    return true;
}

std::string ClusterFinder::MasterAddr(bool update) {
    if (!FLAGS_tera_zk_enabled) {
        // use local file system as a fake zk
        std::string master_node =
            FLAGS_tera_fake_zk_path_prefix + kMasterLockPath + "/0";
        if (!zk::FakeZkUtil::ReadNode(master_node, &_master_addr)) {
            LOG(FATAL) << "fail to read fake master node: " << master_node;
        }
        return _master_addr;
    }
    if (update || _master_addr == "") {
        if (!ReadZkNode(kMasterNodePath, &_master_addr)) {
            _master_addr = "";
        }
    }
    return _master_addr;
}

std::string ClusterFinder::RootTableAddr(bool update) {
    if (!FLAGS_tera_zk_enabled) {
        // use local file system as a fake zk
        std::string root_node = FLAGS_tera_fake_zk_path_prefix + kRootTabletNodePath;
        if (!zk::FakeZkUtil::ReadNode(root_node, &_root_table_addr)) {
            LOG(FATAL) << "fail to read fake master node: " << root_node;
        }
        return _root_table_addr;
    }
    if (update || _root_table_addr == "") {
        if (!ReadZkNode(kRootTabletNodePath, &_root_table_addr)) {
            _root_table_addr = "";
        }
    }
    return _root_table_addr;
}

}  // namespace sdk
}  // namespace tera
